import asyncio
import pandas as pd
import aiosqlite
import concurrent.futures
import matplotlib.pyplot as plt
from typing import Any, Dict, List
from analyzer.analyzer import Analyzer
from datetime import datetime

DataFrame = pd.DataFrame
Queue = asyncio.Queue
def process_group(date: str, group: DataFrame, short_window: int, long_window: int) -> List[Dict[str, Any]]:
    """
    Process each group of data within the specified date range.

    Parameters:
        date (str): The date of the group.
        group (DataFrame): A group of data for the specified date.
        short_window (int): The short moving average window.
        long_window (int): The long moving average window.

    Returns:
        List[Dict[str, Any]]: List of tradebook dictionaries.
    """
    tradebook = []
    stop_loss = 20
    exit_time = pd.Timestamp(year=group['timestamp'].iloc[0].year,
                             month=group['timestamp'].iloc[0].month,
                             day=group['timestamp'].iloc[0].day,
                             hour=15,
                             minute=0)
    in_trade = False
    entry_time = None
    entry_price = None
    pnl = 0
    trades_per_day = 0
    
    for index, row in group.iterrows():
        if row['timestamp'].time() >= pd.Timestamp('09:20').time():
            if not in_trade and row['short_ma'] > row['long_ma']:
                in_trade = True
                entry_time = row['timestamp']
                entry_price = row['close']
                trades_per_day += 1
            elif in_trade and (row['timestamp'] == exit_time or row['short_ma'] < row['long_ma'] or row['close'] < entry_price - stop_loss):
                in_trade = False
                exit_time = row['timestamp']
                exit_price = row['close']
                pnl = exit_price - entry_price
                tradebook.append({'entry_time': entry_time,
                                  'exit_time': exit_time,
                                  'entry_price': entry_price,
                                  'exit_price': exit_price,
                                  'pnl': pnl,
                                  'trades_per_day': trades_per_day})
    return tradebook


        
 

def moving_crossover_strategy(df: DataFrame, short_window: int = 50, long_window: int = 200) -> DataFrame:
    """
    Apply moving crossover strategy to the DataFrame.

    Parameters:
        df (DataFrame): Input DataFrame containing OHLC data.
        short_window (int): The short moving average window.
        long_window (int): The long moving average window.

    Returns:
        DataFrame: Tradebook containing trade details.
    """
    df['short_ma'] = df['close'].rolling(window=short_window, min_periods=1).mean()
    df['long_ma'] = df['close'].rolling(window=long_window, min_periods=1).mean()

    grouped = df.groupby(df['timestamp'].dt.date)
    tradebooks = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_group = {executor.submit(process_group, date, group, short_window, long_window): (date, group) for date, group in grouped}
        for future in concurrent.futures.as_completed(future_to_group):
            date, group = future_to_group[future]
            try:
                tradebooks.append(future.result())
            except Exception as exc:
                print(f"Exception occurred for date {date}: {exc}")
    return pd.DataFrame([trade for trades in tradebooks for trade in trades])


async def evaluate_strategy(queue, strategy):
    """
    Evaluate the strategy using  data from the queue.

    Parameters:
        queue (asyncio.Queue): Queue containing  data.
    """
    collective_df =[]
    tradebooks = []
    while True:
        data = await queue.get()
        if data is None:  
            print("Received None, breaking the loop")  
            break
        if data:  
            df = pd.DataFrame(data)
            column_names = ["id", "timestamp", "symbol", "expiry", "type", "strike", "open", "high", "low", "close", "oi", "volume", "provider", "upload_time"]
            df.columns = column_names
            df = df[df['symbol'] == f'{strategy.instrument}-I.NFO']
            df = df[['timestamp', 'symbol', 'open' , 'high' , 'low', 'close']]
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.sort_values(by='timestamp', inplace=True)
            df.reset_index(inplace=True, drop=True)
            # print(df)
            collective_df.append(df)
            tradebook = moving_crossover_strategy(df, strategy.short_ma, strategy.long_ma)
            tradebooks.append(tradebook)
        queue.task_done()
    if tradebooks:
        collective_tradebook = pd.concat(tradebooks, ignore_index=True)
        collective_df= pd.concat(collective_df, ignore_index=True)
        collective_df =collective_df.set_index('timestamp').resample('D').agg({'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last'}).dropna()
        collective_df['date'] = collective_df.index.date
        collective_df.to_csv('daily_ohlc.csv',index=False)
        # print(collective_df)
        cumulative_pnl = collective_tradebook['pnl'].cumsum()
        collective_tradebook.to_csv(f'./strategy/moving_average/{strategy.strat_name}_{strategy.instrument}_{strategy.short_ma}_{strategy.long_ma}_tradebook.csv',index=False)
        # print(collective_tradebook)