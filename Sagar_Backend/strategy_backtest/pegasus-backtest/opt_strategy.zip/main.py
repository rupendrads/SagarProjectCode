import asyncio
import pandas as pd
from analyzer.analyzer import Analyzer
from data.data import fetch_data_and_filter
from opt_strategy.moving_average import evaluate_strategy
from typing import Any, Dict, List
from datetime import datetime
from strategy.strategy import Strategy
from optimizer.optimizer import ParameterOptimizer
async def run_backtest_moving_strategy(strategy : Strategy) -> None:
    """
    Function to run backtest with moving average strategy.
    """
    queue = asyncio.Queue()
    await fetch_data_and_filter(strategy.start_date, strategy.end_date, strategy.instrument, queue)
    await evaluate_strategy(queue, strategy)
    tradebook_path = f'./strategy/moving_average/{strategy.strat_name}_{strategy.instrument}_{strategy.short_ma}_{strategy.long_ma}_tradebook.csv'
    analyzer = Analyzer(tradebook_path)
    df = pd.read_csv(tradebook_path)
    analyzer.plot_data()

    daily_returns_df = pd.read_csv('daily_returns.csv')
    ohlc_data_df = pd.read_csv('daily_ohlc.csv', usecols=['date', 'open', 'high', 'low', 'close'])

    merged_df = pd.merge(daily_returns_df, ohlc_data_df, on='date', how='left')
    print(merged_df)
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    merged_df.to_csv(f'./strategy/moving_average/{strategy.strat_name}_{strategy.instrument}_{strategy.short_ma}_{strategy.long_ma}_daily_returns.csv', index=False)

async def main() -> None:
    """
    main function.
    """
    # start_date = '2021-01-01'
    # end_date = '2021-12-30'
    # symbol = 'NIFTY'
    # strategy = Strategy()
    # optimizer_parameters ={("start_time", "9:30", "9:30", "14:10", "15") , ("end_time","14:00", "14:00", "15:15", "15") ("short_ma", 10, 7, 100, 1 ), ("long_ma", 14, 10, 120, 1 ), "timeframe": [5, '15', '30m']}
    # strategy = Strategy(strat_name='moving_average', start_date='2020-01-01', end_date='2021-12-30',instrument='NIFTY',is_intraday=True, start_time='9:30', end_time='3:15', capital=200000, timeframe = "1min", lots=1, short_ma = 15, long_ma=20)
    parameters = [
        ("start_time", "9:30", ["9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00"]),
        ("end_time", "14:00", ["14:00", "14:15", "14:30", "14:45", "15:00", "15:15"]),
        ("short_ma", 10, list(range(7, 101))),
        ("long_ma", 14, list(range(10, 121))),
        ("timeframe", '1m', ['1m'])
    ]

    optimizer = ParameterOptimizer(parameters)
    combinations = optimizer.generate_combinations()
    # optimizer.display_combinations(combinations)
    for combination in combinations:
        strat_kwargs = dict(combination)
        strat_kwargs['strat_name'] = 'moving_average'
        strat_kwargs['start_date'] = '2020-01-01'
        strat_kwargs['end_date'] = '2021-12-30'
        strat_kwargs['instrument'] = 'NIFTY'
        strat_kwargs['is_intraday'] = True
        strategy = Strategy(**strat_kwargs)
        # strategy.display_parameters()
        await run_backtest_moving_strategy(strategy)
        print()
    await run_backtest_moving_strategy(strategy)

asyncio.run(main())
