import pandas_ta as ta

class TechnicalIndicators:
    def __init__(self, data):
        self.data = data

    def calculate_sma(self, window):
        return ta.sma(self.data['close'], length=window)

    def calculate_ema(self, window):
        return ta.ema(self.data['close'], length=window)

    def calculate_dema(self, window):
        return ta.dema(self.data['close'], length=window)

    def calculate_tema(self, window):
        return ta.tema(self.data['close'], length=window)

    def calculate_kama(self, window=None, fast=None, slow=None):
        return ta.kama(self.data['close'], length=window, fast=fast, slow=slow)

    def calculate_rsi(self, window):
        return ta.rsi(self.data['close'], length=window)

    def calculate_bollinger_bands(self, window):
        return ta.bbands(self.data['close'], length=window)

    def calculate_macd(self):
        return ta.macd(self.data['close'])

    def calculate_dmi(self, window):
        return ta.dmi(self.data['high'], self.data['low'], self.data['close'], length=window)

    def calculate_obv(self):
        return ta.on_balance_volume(self.data['close'], self.data['volume'])

    def calculate_mfi(self, window):
        return ta.mfi(self.data['high'], self.data['low'], self.data['close'], self.data['volume'], length=window)


