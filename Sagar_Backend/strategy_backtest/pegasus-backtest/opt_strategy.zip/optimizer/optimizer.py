from itertools import product

class ParameterOptimizer:
    def __init__(self, parameters):
        self.parameters = parameters

    def generate_combinations(self):
        # Generate permutations for each parameter
        permutations = []
        for parameter in self.parameters:
            name, default, values = parameter
            if isinstance(values, list):
                valid_values = [val for val in values if val >= default]  
                permutations.append([(name, val) for val in valid_values])
            else:
                print(f"Ignoring parameter '{name}' with invalid range type.")
                continue

        # Generate combinations
        combinations = list(product(*permutations))
        return combinations[:10]  

    def display_combinations(self, combinations):
        print(f"Total number of generated combinations are {len(combinations)}")
        
        for i, combination in enumerate(combinations, start=1):
            print(f"Combination {i}: {combination}")




    