import asyncio
import pandas as pd
import aiosqlite
import concurrent.futures
import matplotlib.pyplot as plt
from typing import Any, Dict, List
DataFrame = pd.DataFrame
Queue = asyncio.Queue

path = r'C:\Users\pegas\OneDrive\Desktop\zip data\index_data.db'

async def fetch_data(start_date: str, end_date: str, symbol: str, conn: aiosqlite.Connection, queue: Queue) -> None:
    """
    Fetch data from the database within the specified date range.

    Parameters:
        start_date (str): Start date of the data to fetch.
        end_date (str): End date of the data to fetch.
        symbol (str): Symbol or instrument to fetch data for.
        conn (aiosqlite.Connection): SQLite database connection.
        queue (asyncio.Queue): Queue to store data.
    """
    print(f'Fetching data from {start_date} to {end_date}')
    
    start_year = pd.Timestamp(start_date).year
    end_year = pd.Timestamp(end_date).year
    
    data = []
    
    for year in range(start_year, end_year + 1):
        table_name = f'{symbol}_{year}'
        query = f'''
                SELECT *
                FROM {table_name}
                WHERE timestamp BETWEEN ? AND ?
                AND type = 'FUT'
                '''
        async with conn.execute(query, (start_date, end_date)) as cursor:
            year_data = await cursor.fetchall()
        data.extend(year_data)
    
    await queue.put(data)
    print('Fetching done')

async def fetch_data_and_filter(start_date: str, end_date: str, symbol: str, queue: Queue) -> None:
    """
    Fetch data for the specified date range, and put it into the queue for further processing.

    Parameters:
        start_date (str): Start date of the data to fetch.
        end_date (str): End date of the data to fetch.
        symbol (str): Symbol or instrument to fetch data for.
        queue (asyncio.Queue): Queue to store data.
    """
    try:
        conn = await aiosqlite.connect(path)
        print(path)
        
        date_range = pd.date_range(start=start_date, end=end_date, freq='D')
        interval_size = len(date_range) // 10    #interval size
        for i in range(0, len(date_range), interval_size):
            interval_start = date_range[i]
            if i + interval_size < len(date_range):
                interval_end = date_range[i + interval_size]
            else:
                interval_end = date_range[-1]
            
            await fetch_data(interval_start.strftime('%Y-%m-%d'), interval_end.strftime('%Y-%m-%d'), symbol, conn, queue)
        
        await conn.close()
        await queue.put(None)
    except Exception as e:
        print(f'Error occurred while fetching data: {e}')